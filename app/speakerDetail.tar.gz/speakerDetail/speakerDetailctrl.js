export default class speakerDetailctrl{
  /*@ngInject;*/
  constructor($scope , $location,$http, detailfact,$routeParams, $localStorage){
    this.loc=$location;
    this.rp=$routeParams;
    this.scope=$scope;
    this.http=$http;
    this.ls=$localStorage;
    this.scope.rate=0;
    this.scope.rateflag=false;
    this.scope.count=0;
    this.scope.starflag=false;
    this.scope.single_event=[];
    this.services=detailfact;
    console.log(this.rp);
    this.services.getspeakerDetails().success((res)=>{
      this.scope.detail=res.speakers;
      console.log(res.speakers);
  })
  

}

}
